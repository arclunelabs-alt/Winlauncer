package com.arclune.winlauncher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast

enum class Panel { NONE, START, SEARCH, WIDGETS, QS, NOTIF }

class MainActivity : Activity() {
    lateinit var taskbar: Taskbar
    lateinit var windows: Windows
    var batteryLevel = 1f
    var charging = false
    var currentPanel = Panel.NONE
        private set

    private lateinit var outer: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var wallpaper: WallpaperView
    private lateinit var desktop: FrameLayout
    private lateinit var winLayer: FrameLayout
    private lateinit var scrim: View
    private lateinit var start: StartMenu
    private lateinit var quick: QuickPanel
    private lateinit var notif: NotifPanel
    private lateinit var widgets: WidgetsPanel
    private var taskView: TaskView? = null
    private var touchX = 0
    private var touchY = 0
    private val taskbarH get() = dp(48)

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.load(this)
        AppRepo.load(this)
        getSharedPreferences("win11apps", Context.MODE_PRIVATE).edit().remove("running").apply()

        outer = FrameLayout(this)
        wallpaper = WallpaperView(this)
        outer.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        content = FrameLayout(this)
        outer.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(outer)

        // desktop + layer jendela
        desktop = FrameLayout(this)
        content.addView(desktop, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = taskbarH })
        winLayer = FrameLayout(this)
        content.addView(winLayer, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = taskbarH })
        windows = Windows(this, winLayer)

        // scrim untuk menutup panel saat tap di luar
        scrim = View(this).apply {
            visibility = View.GONE
            isClickable = true
            setOnClickListener { open(Panel.NONE) }
        }
        content.addView(scrim, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = taskbarH })

        // panel
        start = StartMenu(this); quick = QuickPanel(this); notif = NotifPanel(this); widgets = WidgetsPanel(this)
        for (p in listOf<View>(start, quick, notif, widgets)) { p.visibility = View.GONE; content.addView(p) }

        // taskbar
        taskbar = Taskbar(this)
        content.addView(taskbar, FrameLayout.LayoutParams(-1, taskbarH, Gravity.BOTTOM))

        buildDesktop()
        handleInsets()
        registerReceivers()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // tombol Home = tombol Windows: buka/tutup Start
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) {
            if (currentPanel == Panel.NONE) open(Panel.START) else open(Panel.NONE)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (currentPanel != Panel.NONE) open(Panel.NONE) }

    override fun onResume() {
        super.onResume()
        taskbar.refresh()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) { touchX = ev.rawX.toInt(); touchY = ev.rawY.toInt() }
        return super.dispatchTouchEvent(ev)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    /** Hindari ikon tertutup poni kamera (cutout) di sisi kiri/kanan. */
    private fun handleInsets() {
        outer.setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                val c = ins.displayCutout
                content.setPadding(c?.safeInsetLeft ?: 0, 0, c?.safeInsetRight ?: 0, 0)
            }
            ins
        }
        outer.requestApplyInsets()
    }

    private fun registerReceivers() {
        val bat = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                batteryLevel = lvl / scale.toFloat()
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                if (::taskbar.isInitialized) taskbar.updateStatus()
            }
        }
        registerReceiver(bat, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        val pkg = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                AppRepo.load(this@MainActivity); taskbar.refresh()
            }
        }
        registerReceiver(pkg, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        })
    }

    // ------------------------------------------------------------------ tema
    fun applyTheme() {
        Theme.save(this)
        wallpaper.invalidate()
        buildDesktop()
        taskbar.refresh()
    }

    // ------------------------------------------------------------------ desktop
    private fun buildDesktop() {
        desktop.removeAllViews()
        desktop.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) { selectIcon(null); open(Panel.NONE) }
            false
        }
        desktop.setOnLongClickListener { desktopMenu(); true }
        if (!Theme.showDesktopIcons) return

        data class Item(val name: String, val glyph: G, val action: () -> Unit)
        val items = listOf(
            Item("Perangkat ini", G.PC) { openThisPc() },
            Item("Recycle Bin", G.TRASH) { openWindow("Recycle Bin", G.TRASH, Apps.recycle(this), 420, 260) },
            Item("Pengaturan", G.SETTINGS) { openSettings(0) },
            Item("File", G.FOLDER) { openFiles() }
        )
        val cell = dp(80)
        val rows = ((resources.displayMetrics.heightPixels - taskbarH - dp(16)) / cell).coerceAtLeast(1)
        items.forEachIndexed { i, item ->
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(6), dp(2), dp(4))
                isClickable = true
                setOnClickListener { selectIcon(this); item.action() }
            }
            v.addView(Glyph(this, item.glyph).apply { layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)) })
            v.addView(label(this, item.name, 11f, Color.WHITE).apply {
                gravity = Gravity.CENTER; maxLines = 2
                setShadowLayer(4f, 0f, 1f, 0xCC000000.toInt())
                setPadding(0, dp(4), 0, 0)
            })
            desktop.addView(v, FrameLayout.LayoutParams(dp(76), dp(76)).apply {
                leftMargin = dp(8) + (i / rows) * dp(80); topMargin = dp(8) + (i % rows) * cell
            })
        }
    }

    private var selected: View? = null
    private fun selectIcon(v: View?) {
        selected?.background = null
        selected = v
        v?.background = rounded(this, 0x44FFFFFF, 5, 0x66FFFFFF, 1)
    }

    private fun desktopMenu() {
        showMenu(this, touchX, touchY, listOf(
            MenuItem("Segarkan", G.BACK) { AppRepo.load(this); buildDesktop(); taskbar.refresh() },
            MenuItem(""),
            MenuItem("Ganti wallpaper", G.PALETTE) { Theme.wallpaper = (Theme.wallpaper + 1) % 3; applyTheme() },
            MenuItem(if (Theme.dark) "Mode terang" else "Mode gelap", G.NIGHT) { Theme.dark = !Theme.dark; applyTheme() },
            MenuItem(if (Theme.showDesktopIcons) "Sembunyikan ikon desktop" else "Tampilkan ikon desktop", G.FOLDER) {
                Theme.showDesktopIcons = !Theme.showDesktopIcons; applyTheme()
            },
            MenuItem(""),
            MenuItem("Pengaturan tampilan", G.SUN) { startSafe(Intent(Settings.ACTION_DISPLAY_SETTINGS)) },
            MenuItem("Personalisasi", G.PALETTE) { openSettings(1) }
        ))
    }

    // ------------------------------------------------------------------ panel
    fun open(p: Panel) {
        hideKeyboardIfNeeded()
        val target = if (p == currentPanel) Panel.NONE else p
        panelView(currentPanel)?.let { hidePanel(it) }
        currentPanel = target
        scrim.visibility = if (target == Panel.NONE) View.GONE else View.VISIBLE
        if (target == Panel.NONE) return
        val v = panelView(target) ?: return
        val dm = resources.displayMetrics
        val gap = dp(12)
        val lp: FrameLayout.LayoutParams
        when (target) {
            Panel.START, Panel.SEARCH -> {
                start.show(if (target == Panel.SEARCH) 1 else 0)
                lp = FrameLayout.LayoutParams(start.panelWidth(), start.panelHeight(),
                    if (Theme.centered) Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL else Gravity.BOTTOM or Gravity.START)
                if (!Theme.centered) lp.leftMargin = gap
            }
            Panel.QS -> {
                quick.refresh()
                lp = FrameLayout.LayoutParams(quick.panelWidth(), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
                lp.rightMargin = gap
            }
            Panel.NOTIF -> {
                notif.refresh()
                lp = FrameLayout.LayoutParams(notif.panelWidth(), notif.panelHeight(), Gravity.BOTTOM or Gravity.END)
                lp.rightMargin = gap
            }
            else -> {
                widgets.refresh()
                lp = FrameLayout.LayoutParams(widgets.panelWidth(), widgets.panelHeight(), Gravity.BOTTOM or Gravity.START)
                lp.leftMargin = gap
            }
        }
        lp.bottomMargin = taskbarH + gap
        v.layoutParams = lp
        v.visibility = View.VISIBLE
        v.alpha = 0f
        v.translationY = dp(36).toFloat()
        if (target == Panel.WIDGETS) { v.translationY = 0f; v.translationX = -dp(60).toFloat() }
        v.animate().alpha(1f).translationY(0f).translationX(0f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun panelView(p: Panel): View? = when (p) {
        Panel.START, Panel.SEARCH -> start
        Panel.QS -> quick
        Panel.NOTIF -> notif
        Panel.WIDGETS -> widgets
        Panel.NONE -> null
    }

    private fun hidePanel(v: View) {
        v.animate().alpha(0f).translationY(dp(24).toFloat()).setDuration(120).withEndAction {
            // jangan sembunyikan bila panel yang sama sudah dibuka lagi
            if (panelView(currentPanel) !== v) v.visibility = View.GONE
        }.start()
    }

    private fun hideKeyboardIfNeeded() { if (::start.isInitialized) start.hideKeyboard() }

    // ------------------------------------------------------------------ jendela
    fun openWindow(title: String, glyph: G, view: View, wDp: Int, hDp: Int) {
        open(Panel.NONE)
        val d = resources.displayMetrics.density
        val maxW = ((resources.displayMetrics.widthPixels) / d).toInt() - 24
        val maxH = ((resources.displayMetrics.heightPixels - taskbarH) / d).toInt() - 12
        val f = WindowFrame(this, title, glyph, view, minOf(wDp, maxW), minOf(hDp, maxH))
        windows.open(f)
        taskView?.let { toggleTaskView() }
    }

    fun openThisPc() = openWindow("Perangkat ini", G.PC, Apps.thisPc(this), 520, 300)

    /** Buka jendela Pengaturan. [reopen] mempertahankan posisi saat ganti halaman/tema. */
    fun openSettings(page: Int, reopen: Boolean = false) {
        val old = windows.closeNow("Pengaturan")
        openWindow("Pengaturan", G.SETTINGS, Apps.settings(this, page), 660, 330)
        if (old != null) windows.all().firstOrNull { it.title == "Pengaturan" }?.let { w ->
            w.post { w.x = old.first; w.y = old.second }
        }
    }

    fun toggleTaskView() {
        val existing = taskView
        if (existing != null) {
            content.removeView(existing); taskView = null; return
        }
        open(Panel.NONE)
        val tv = TaskView(this)
        taskView = tv
        content.addView(tv, content.indexOfChild(taskbar), FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = taskbarH })
        tv.alpha = 0f; tv.animate().alpha(1f).setDuration(160).start()
    }

    fun showDesktop() {
        open(Panel.NONE)
        taskView?.let { toggleTaskView() }
        windows.minimizeAll()
    }

    // ------------------------------------------------------------------ aksi umum
    fun launchApp(app: AppInfo) {
        open(Panel.NONE)
        AppRepo.launch(this, app)
        taskbar.refresh()
    }

    fun showAppMenu(anchor: View, app: AppInfo, fromTaskbar: Boolean) = appMenu(this, anchor, app, fromTaskbar)

    fun showPowerMenu(anchor: View) {
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        showMenu(this, loc[0] + anchor.width, loc[1], listOf(
            MenuItem("Tutup semua jendela", G.CLOSE) { windows.all().forEach { windows.close(it) }; open(Panel.NONE) },
            MenuItem("Muat ulang launcher", G.BACK) { recreate() },
            MenuItem(""),
            MenuItem("Pengaturan Android", G.SETTINGS) { startSafe(Intent(Settings.ACTION_SETTINGS)) }
        ), above = true)
    }

    fun startSafe(i: Intent) {
        open(Panel.NONE)
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "Tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show() }
    }

    fun openFiles() {
        val pm = packageManager
        val i = listOf("com.google.android.documentsui", "com.android.documentsui", "com.sec.android.app.myfiles")
            .firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
        if (i != null) startSafe(i) else startSafe(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
    }
}
