package com.arclune.winlauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Membaca notifikasi asli untuk ditampilkan di Notification Center. */
class NotifService : NotificationListenerService() {
    companion object {
        var instance: NotifService? = null
        fun list(): List<StatusBarNotification> =
            try { instance?.activeNotifications?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }
}
