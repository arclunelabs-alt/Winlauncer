package com.arclune.winlauncher

import android.animation.ValueAnimator
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout

/** Jendela mengambang bergaya Windows 11: title bar, min/max/close, bisa digeser. */
class WindowFrame(
    val a: MainActivity,
    val title: String,
    val glyph: G,
    val content: View,
    val wDp: Int = 560,
    val hDp: Int = 340
) : LinearLayout(a) {
    var minimized = false
    var maximized = false
    var isFocusedWin = false
    private var restore = floatArrayOf(0f, 0f, 0f, 0f)
    lateinit var wm: Windows
    private val titleBar = LinearLayout(a)
    private var dx = 0f
    private var dy = 0f

    init {
        orientation = VERTICAL
        elevation = a.dpf(16f)
        background = rounded(a, Theme.surfaceSolid, 8, Theme.stroke)
        clipToOutline = true

        titleBar.apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(if (Theme.dark) 0xFF202020.toInt() else 0xFFF3F3F3.toInt())
            setPadding(a.dp(12), 0, 0, 0)
        }
        titleBar.addView(Glyph(a, glyph).apply { layoutParams = LayoutParams(a.dp(16), a.dp(16)) })
        titleBar.addView(label(a, title, 12f).apply {
            setPadding(a.dp(10), 0, 0, 0)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f)
        })
        titleBar.addView(capBtn(G.MIN, false) { wm.minimize(this) })
        titleBar.addView(capBtn(G.MAX, false) { toggleMax() })
        titleBar.addView(capBtn(G.CLOSE, true) { wm.close(this) })
        addView(titleBar, LayoutParams(LayoutParams.MATCH_PARENT, a.dp(34)))
        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        // geser jendela lewat title bar
        titleBar.setOnTouchListener { _, e ->
            wm.focus(this)
            if (maximized) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = x - e.rawX; dy = y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val p = parent as View
                    x = (e.rawX + dx).coerceIn(-width * 0.7f, p.width - width * 0.3f)
                    y = (e.rawY + dy).coerceIn(0f, (p.height - a.dp(48)).toFloat())
                }
            }
            true
        }
        setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) wm.focus(this); false }
    }

    private fun capBtn(g: G, close: Boolean, click: () -> Unit): View {
        val gl = Glyph(a, g)
        val f = FrameLayout(a)
        f.addView(gl, FrameLayout.LayoutParams(a.dp(14), a.dp(14), Gravity.CENTER))
        f.background = hoverBg(a, 0, 0)
        f.setOnClickListener { click() }
        if (close) f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.setBackgroundColor(0xFFC42B1C.toInt()); gl.tint = Color.WHITE; gl.invalidate() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.background = hoverBg(a, 0, 0); gl.tint = 0; gl.invalidate()
                }
            }
            false
        }
        f.layoutParams = LayoutParams(a.dp(46), LayoutParams.MATCH_PARENT)
        return f
    }

    fun toggleMax() {
        val p = parent as View
        if (!maximized) {
            restore = floatArrayOf(x, y, width.toFloat(), height.toFloat())
            animateTo(0f, 0f, p.width, p.height)
            maximized = true
        } else {
            animateTo(restore[0], restore[1], restore[2].toInt(), restore[3].toInt())
            maximized = false
        }
    }

    private fun animateTo(nx: Float, ny: Float, nw: Int, nh: Int) {
        val sx = x; val sy = y; val sw = width; val sh = height
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 180
            addUpdateListener {
                val t = it.animatedValue as Float
                x = sx + (nx - sx) * t; y = sy + (ny - sy) * t
                val lp = layoutParams
                lp.width = (sw + (nw - sw) * t).toInt(); lp.height = (sh + (nh - sh) * t).toInt()
                layoutParams = lp
            }
            start()
        }
    }

    fun setFocusedLook(f: Boolean) {
        isFocusedWin = f
        elevation = a.dpf(if (f) 24f else 8f)
        alpha = if (f) 1f else 0.96f
    }
}

/** Mengelola daftar jendela: buka, fokus, minimize, tutup. */
class Windows(private val a: MainActivity, private val layer: FrameLayout) {
    private val list = mutableListOf<WindowFrame>()
    fun all(): List<WindowFrame> = list.toList()

    fun open(w: WindowFrame) {
        // satu jendela per judul
        list.firstOrNull { it.title == w.title }?.let { restoreWin(it); return }
        w.wm = this
        val p = a.dp(0)
        val lp = FrameLayout.LayoutParams(a.dp(w.wDp), a.dp(w.hDp))
        layer.addView(w, lp)
        w.x = (layer.width - a.dp(w.wDp)) / 2f + list.size * a.dp(28) + p
        w.y = a.dp(34).toFloat() + list.size * a.dp(28)
        list.add(w)
        w.alpha = 0f; w.scaleX = 0.92f; w.scaleY = 0.92f
        w.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
        focus(w)
    }

    private fun restoreWin(w: WindowFrame) {
        if (w.minimized) {
            w.minimized = false
            w.visibility = View.VISIBLE
            w.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(160).start()
        }
        focus(w)
    }

    fun focus(w: WindowFrame) {
        w.bringToFront()
        for (o in list) o.setFocusedLook(o === w)
        a.taskbar.refresh()
    }

    fun minimize(w: WindowFrame) {
        w.minimized = true
        w.setFocusedLook(false)
        w.animate().alpha(0f).translationY(a.dp(60).toFloat()).scaleX(0.9f).scaleY(0.9f).setDuration(150)
            .withEndAction { if (w.minimized) w.visibility = View.GONE }.start()
        a.taskbar.refresh()
    }

    fun toggle(w: WindowFrame) {
        if (w.minimized) restoreWin(w)
        else if (w.isFocusedWin) minimize(w)
        else focus(w)
    }

    fun close(w: WindowFrame) {
        w.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(130).withEndAction {
            layer.removeView(w); list.remove(w); a.taskbar.refresh()
        }.start()
    }

    /** Tutup tanpa animasi; mengembalikan posisi terakhir (untuk dibuka ulang di tempat sama). */
    fun closeNow(title: String): Pair<Float, Float>? {
        val w = list.firstOrNull { it.title == title } ?: return null
        layer.removeView(w); list.remove(w)
        return Pair(w.x, w.y)
    }

    fun minimizeAll() { for (w in list) if (!w.minimized) minimize(w) }
}
