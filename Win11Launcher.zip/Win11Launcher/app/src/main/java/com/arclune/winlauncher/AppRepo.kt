package com.arclune.winlauncher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import java.util.Locale

data class AppInfo(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)

/** Daftar aplikasi, pin taskbar/start, dan riwayat "Recommended". */
object AppRepo {
    var all: List<AppInfo> = emptyList()
    private val prefs get() = ctx.getSharedPreferences("win11apps", Context.MODE_PRIVATE)
    private lateinit var ctx: Context

    fun load(c: Context) {
        ctx = c.applicationContext
        val pm = c.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != c.packageName }
            .map {
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(it.activityInfo.packageName, it.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm), i)
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    fun find(pkg: String) = all.firstOrNull { it.pkg == pkg }

    private fun getList(key: String): MutableList<String> =
        (prefs.getString(key, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun putList(key: String, l: List<String>) = prefs.edit().putString(key, l.joinToString(",")).apply()

    /** Pin Start: default ke 18 aplikasi pertama bila belum diatur. */
    fun pinned(): List<AppInfo> {
        if (!prefs.contains("pinned")) putList("pinned", all.take(18).map { it.pkg })
        return getList("pinned").mapNotNull { find(it) }
    }

    fun taskbarPins(): List<AppInfo> {
        if (!prefs.contains("tbpins")) putList("tbpins", all.take(5).map { it.pkg })
        return getList("tbpins").mapNotNull { find(it) }
    }

    fun isPinned(pkg: String) = getList("pinned").contains(pkg)
    fun isTaskbarPinned(pkg: String) = getList("tbpins").contains(pkg)

    fun togglePin(pkg: String) {
        pinned() // pastikan terinisialisasi
        val l = getList("pinned")
        if (!l.remove(pkg)) l.add(pkg)
        putList("pinned", l)
    }

    fun toggleTaskbarPin(pkg: String) {
        taskbarPins()
        val l = getList("tbpins")
        if (!l.remove(pkg)) l.add(pkg)
        putList("tbpins", l)
    }

    fun recents(): List<AppInfo> = getList("recent").mapNotNull { find(it) }
    fun running(): List<AppInfo> = getList("running").mapNotNull { find(it) }

    fun markRunning(pkg: String, on: Boolean) {
        val l = getList("running"); l.remove(pkg); if (on) l.add(pkg); putList("running", l)
    }

    private fun addRecent(pkg: String) {
        val l = getList("recent"); l.remove(pkg); l.add(0, pkg)
        putList("recent", l.take(6))
    }

    fun launch(c: Context, app: AppInfo) {
        addRecent(app.pkg)
        markRunning(app.pkg, true)
        try {
            if (Theme.windowMode) {
                // Mode jendela: berfungsi bila perangkat mendukung freeform (Developer options).
                val dm = c.resources.displayMetrics
                val w = (dm.widthPixels * 0.62f).toInt()
                val h = (dm.heightPixels * 0.75f).toInt()
                val l = (dm.widthPixels - w) / 2
                val t = c.dp(24)
                val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h))
                c.startActivity(app.intent, opts.toBundle())
            } else c.startActivity(app.intent)
        } catch (e: Exception) {
            markRunning(app.pkg, false)
        }
    }

    fun uninstall(c: Context, pkg: String) {
        c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun appInfo(c: Context, pkg: String) {
        c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun isInstalled(c: Context, pkg: String) = try { c.packageManager.getPackageInfo(pkg, 0); true }
    catch (e: PackageManager.NameNotFoundException) { false }
}
