package com.arclune.winlauncher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import java.util.Locale

data class AppInfo(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)

/** Daftar aplikasi, pin taskbar/start, dan riwayat "Recommended". */
object AppRepo {
    var all: List<AppInfo> = emptyList()
    private val prefs get() = ctx.getSharedPreferences("win11apps", Context.MODE_PRIVATE)
    private lateinit var ctx: Context

    @Volatile var loaded = false

    /** Muat daftar aplikasi di thread latar (ikon dirender sekali ke bitmap seragam). */
    fun loadAsync(c: Context, done: () -> Unit) {
        ctx = c.applicationContext
        Thread {
            val list = scan(ctx)
            Handler(Looper.getMainLooper()).post { all = list; loaded = true; done() }
        }.start()
    }

    private fun scan(c: Context): List<AppInfo> {
        val pm = c.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val size = c.dp(48)
        return pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != c.packageName }
            .map {
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(it.activityInfo.packageName, it.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val icon = try { squircle(c, it.loadIcon(pm), size) } catch (e: Throwable) { it.loadIcon(pm) }
                AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, icon, i)
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    /** Ikon seragam bergaya Windows 11: kotak membulat. Ikon adaptif diisi penuh, ikon lama dibiarkan apa adanya. */
    private fun squircle(c: Context, d: Drawable, px: Int): Drawable {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val r = px * 0.24f
            val clip = Path().apply { addRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, Path.Direction.CW) }
            cv.clipPath(clip)
            val full = (px * 108f / 78f).toInt()
            val off = (px - full) / 2
            val bg = d.background; val fg = d.foreground
            if (bg != null) { bg.setBounds(off, off, off + full, off + full); bg.draw(cv) }
            if (fg != null) { fg.setBounds(off, off, off + full, off + full); fg.draw(cv) }
        } else {
            val inset = (px * 0.04f).toInt()
            d.setBounds(inset, inset, px - inset, px - inset)
            d.draw(cv)
        }
        return BitmapDrawable(c.resources, bmp)
    }

    /** Muat sinkron (dipakai setelah paket berubah dari thread utama sudah cukup cepat lewat loadAsync). */
    fun load(c: Context) { ctx = c.applicationContext; all = scan(ctx); loaded = true }

    fun find(pkg: String) = all.firstOrNull { it.pkg == pkg }

    private fun getList(key: String): MutableList<String> =
        (prefs.getString(key, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun putList(key: String, l: List<String>) = prefs.edit().putString(key, l.joinToString(",")).apply()

    /** Pin Start: default ke 18 aplikasi pertama bila belum diatur. */
    private val favorites = listOf(
        "com.android.chrome", "com.google.android.apps.photos", "com.android.vending", "com.google.android.youtube",
        "com.whatsapp", "com.instagram.android", "com.google.android.apps.maps", "com.google.android.gm",
        "com.google.android.apps.messaging", "com.google.android.dialer", "com.android.camera", "com.sec.android.app.camera",
        "com.google.android.calendar", "com.spotify.music", "com.facebook.katana", "org.telegram.messenger"
    )

    private fun defaultPins(n: Int): List<String> {
        val fav = favorites.filter { f -> all.any { it.pkg == f } }
        return (fav + all.map { it.pkg }).distinct().take(n)
    }

    /** Pin Start: default 12 aplikasi populer yang terpasang. */
    fun pinned(): List<AppInfo> {
        if (all.isEmpty()) return emptyList()
        if (!prefs.contains("pinned")) putList("pinned", defaultPins(12))
        return getList("pinned").mapNotNull { find(it) }
    }

    fun taskbarPins(): List<AppInfo> {
        if (all.isEmpty()) return emptyList()
        if (!prefs.contains("tbpins")) putList("tbpins", defaultPins(5))
        return getList("tbpins").mapNotNull { find(it) }
    }

    fun isPinned(pkg: String) = getList("pinned").contains(pkg)
    fun isTaskbarPinned(pkg: String) = getList("tbpins").contains(pkg)

    fun togglePin(pkg: String) {
        pinned() // pastikan terinisialisasi
        val l = getList("pinned")
        if (!l.remove(pkg)) l.add(pkg)
        putList("pinned", l)
    }

    fun toggleTaskbarPin(pkg: String) {
        taskbarPins()
        val l = getList("tbpins")
        if (!l.remove(pkg)) l.add(pkg)
        putList("tbpins", l)
    }

    fun recents(): List<AppInfo> = getList("recent").mapNotNull { find(it) }
    fun running(): List<AppInfo> = getList("running").mapNotNull { find(it) }

    fun markRunning(pkg: String, on: Boolean) {
        val l = getList("running"); l.remove(pkg); if (on) l.add(pkg); putList("running", l)
    }

    private fun addRecent(pkg: String) {
        val l = getList("recent"); l.remove(pkg); l.add(0, pkg)
        putList("recent", l.take(6))
    }

    fun launch(c: Context, app: AppInfo) {
        addRecent(app.pkg)
        markRunning(app.pkg, true)
        try {
            if (Theme.windowMode) {
                // Mode jendela: berfungsi bila perangkat mendukung freeform (Developer options).
                val dm = c.resources.displayMetrics
                val w = (dm.widthPixels * 0.62f).toInt()
                val h = (dm.heightPixels * 0.75f).toInt()
                val l = (dm.widthPixels - w) / 2
                val t = c.dp(24)
                val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h))
                c.startActivity(app.intent, opts.toBundle())
            } else c.startActivity(app.intent)
        } catch (e: Exception) {
            markRunning(app.pkg, false)
        }
    }

    fun uninstall(c: Context, pkg: String) {
        c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun appInfo(c: Context, pkg: String) {
        c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun isInstalled(c: Context, pkg: String) = try { c.packageManager.getPackageInfo(pkg, 0); true }
    catch (e: PackageManager.NameNotFoundException) { false }
}
