package com.arclune.winlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** Wallpaper prosedural bergaya "Bloom" Windows 11. */
class WallpaperView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    // [latar atas, latar bawah, petal terang, petal gelap]
    private val palettes = arrayOf(
        intArrayOf(0xFF061A4A.toInt(), 0xFF1E6FE0.toInt(), 0xFF7FC4FF.toInt(), 0xFF0A3FA8.toInt()),
        intArrayOf(0xFF1B0B3A.toInt(), 0xFF6C3BD4.toInt(), 0xFFD6A8FF.toInt(), 0xFF4A1D9E.toInt()),
        intArrayOf(0xFF021F1C.toInt(), 0xFF0E8F76.toInt(), 0xFF8CF0D0.toInt(), 0xFF05604F.toInt())
    )
    private val light = arrayOf(
        intArrayOf(0xFFBFE0FF.toInt(), 0xFF5AA7F5.toInt(), 0xFFFFFFFF.toInt(), 0xFF2F7CE0.toInt()),
        intArrayOf(0xFFE8D8FF.toInt(), 0xFFA98BEA.toInt(), 0xFFFFFFFF.toInt(), 0xFF7B52D6.toInt()),
        intArrayOf(0xFFCDF5E9.toInt(), 0xFF5FCFB0.toInt(), 0xFFFFFFFF.toInt(), 0xFF22A187.toInt())
    )

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pal = (if (Theme.dark) palettes else light)[Theme.wallpaper.coerceIn(0, 2)]

        p.shader = LinearGradient(0f, 0f, w * 0.3f, h, pal[0], pal[1], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)

        val cx = w * 0.5f
        val cy = h * 0.52f
        val r = h * 0.62f

        // glow tengah
        p.shader = RadialGradient(cx, cy, r * 1.3f, intArrayOf(pal[2] and 0x00FFFFFF or 0x66000000, 0x00000000),
            null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.3f, p)

        // kelopak bloom
        val petals = 8
        for (i in 0 until petals) {
            c.save()
            c.rotate(i * (360f / petals) + 12f, cx, cy)
            oval.set(cx - r * 0.20f, cy - r * 0.95f, cx + r * 0.20f, cy + r * 0.05f)
            p.shader = LinearGradient(
                cx, cy - r * 0.95f, cx, cy,
                intArrayOf(pal[3] and 0x00FFFFFF or 0xCC000000.toInt(), pal[2] and 0x00FFFFFF or 0xDD000000.toInt()),
                null, Shader.TileMode.CLAMP
            )
            c.drawOval(oval, p)
            // kelopak dalam lebih terang
            c.scale(0.62f, 0.62f, cx, cy)
            p.shader = LinearGradient(
                cx, cy - r * 0.95f, cx, cy,
                intArrayOf(pal[2] and 0x00FFFFFF or 0x99000000.toInt(), Color.argb(40, 255, 255, 255)),
                null, Shader.TileMode.CLAMP
            )
            c.drawOval(oval, p)
            c.restore()
        }

        // vignette lembut
        p.shader = RadialGradient(cx, cy, w * 0.75f, intArrayOf(0x00000000, if (Theme.dark) 0x66000000 else 0x1A000000),
            null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }
}
