# Win11 Launcher untuk Android (Landscape) — v1.1

Launcher Android bertema Windows 11 — desktop, taskbar, Start menu, jendela, dan panel Quick Settings.
Tanpa library eksternal (hanya Android framework), minSdk 26, wajib landscape.

## Fitur
- **Taskbar** Win11 dengan efek kaca (blur): ikon di tengah/kiri, Start, Search, Task View, Widgets, app tersemat + indikator, tray, jam.
- **Start menu**: pencarian, aplikasi bawaan + pin, *Semua aplikasi* (daftar virtual, ringan), rekomendasi, power menu.
- **Jendela mengambang**: geser, **resize** (tarik pojok kanan-bawah), **snap** (seret ke tepi kiri/kanan/atas, atau tahan tombol maximize), minimize, close.
- **Aplikasi bawaan**: File Explorer (buka/ganti nama/hapus/folder baru), Kalkulator, Notepad (tersimpan otomatis), Jam + stopwatch, Pengaturan, Perangkat ini.
- **Desktop**: ikon bisa digeser (tahan lalu seret), "Kirim ke desktop" dari menu aplikasi, menu klik-kanan.
- **Personalisasi**: gelap/terang, 6 warna aksen, 6 wallpaper + foto dari galeri, efek kaca on/off, taskbar tengah/kiri.
- Ikon aplikasi diseragamkan jadi kotak membulat; aplikasi dimuat di background supaya tidak lag.
- Tombol **Home = tombol Windows**.

## Izin
File Explorer butuh "Akses semua file" (tombol Izinkan muncul di jendelanya). Akses notifikasi untuk panel notifikasi.

## Cara mendapatkan APK
### A. Tanpa install apa pun (GitHub Actions)
1. Buat repo GitHub baru, upload seluruh isi folder ini.
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis saat push).
3. Setelah hijau, unduh artifact **Win11Launcher-debug** → `app-debug.apk`, pasang di HP.

### B. Android Studio
Open folder ini → tunggu sync → **Build > Build APK(s)**.

## Setelah dipasang
1. Tekan Home → pilih **Win11 Launcher** → *Selalu*.
2. Beri **akses notifikasi** (Pengaturan > Sistem > Notifikasi) agar notifikasi muncul di panel.
3. Opsional: izinkan *Ubah pengaturan sistem* agar slider kecerahan mengubah kecerahan seluruh HP.
4. Mode jendela aplikasi (Pengaturan > Personalisasi) hanya bekerja jika HP mendukung **Freeform windows** (Opsi Pengembang).

## Catatan jujur
Kode ini ditulis tanpa bisa dikompilasi di lingkungan pembuatnya (tidak ada akses ke repo Android),
jadi build pertama bisa menunjukkan beberapa error kecil. Kirim log error-nya, mudah diperbaiki.
