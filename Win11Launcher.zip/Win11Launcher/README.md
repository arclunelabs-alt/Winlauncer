# Win11 Launcher untuk Android (Landscape)

Launcher Android bertema Windows 11 — desktop, taskbar, Start menu, jendela, dan panel Quick Settings.
Tanpa library eksternal (hanya Android framework), minSdk 26, wajib landscape.

## Fitur
- **Taskbar** Win11: ikon di tengah (atau kiri), Start, Search, Task View, Widgets, app tersemat + indikator app berjalan, tray (Wi-Fi/volume/baterai), jam & tanggal, sliver "Show desktop".
- **Start menu**: pencarian langsung, grid *Disematkan*, *Semua aplikasi* (A–Z), *Rekomendasi* (app terakhir dibuka), profil + tombol power. Tahan lama pada app untuk menu (sematkan, info, copot).
- **Jendela mengambang**: Pengaturan, Perangkat ini, Recycle Bin — bisa digeser, minimize, maximize, tutup.
- **Task View** dengan thumbnail jendela, **Quick Settings** (tile, kecerahan, volume), **Notification Center** + kalender, **Widgets** (baterai, penyimpanan, catatan cepat).
- **Personalisasi**: mode gelap/terang, 6 warna aksen, 3 wallpaper Bloom, taskbar tengah/kiri, ikon desktop.
- Tombol **Home = tombol Windows** (buka/tutup Start). Klik-kanan (tahan) desktop untuk menu konteks.

## Cara mendapatkan APK
### A. Tanpa install apa pun (GitHub Actions)
1. Buat repo GitHub baru, upload seluruh isi folder ini.
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis saat push).
3. Setelah hijau, unduh artifact **Win11Launcher-debug** → `app-debug.apk`, pasang di HP.

### B. Android Studio
Open folder ini → tunggu sync → **Build > Build APK(s)**.

## Setelah dipasang
1. Tekan Home → pilih **Win11 Launcher** → *Selalu*.
2. Beri **akses notifikasi** (Pengaturan > Sistem > Notifikasi) agar notifikasi muncul di panel.
3. Opsional: izinkan *Ubah pengaturan sistem* agar slider kecerahan mengubah kecerahan seluruh HP.
4. Mode jendela aplikasi (Pengaturan > Personalisasi) hanya bekerja jika HP mendukung **Freeform windows** (Opsi Pengembang).

## Catatan jujur
Kode ini ditulis tanpa bisa dikompilasi di lingkungan pembuatnya (tidak ada akses ke repo Android),
jadi build pertama bisa menunjukkan beberapa error kecil. Kirim log error-nya, mudah diperbaiki.
